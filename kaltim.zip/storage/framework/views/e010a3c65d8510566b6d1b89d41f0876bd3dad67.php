<div class="col-md-4">
    <div class="card">
        <div class="card-body">
            <div id="calendar"></div>
        </div>
    </div>
</div><?php /**PATH D:\laravel\kaltim\resources\views/backend/template/component/calender.blade.php ENDPATH**/ ?>