

<?php $__env->startSection('content'); ?>
<center>
    <div class="row mb-4">
        <div class="float-left col-md-11">
            <h3 style="color:white"><b>Polres</b></h3>
        </div>
        <div class="float-right col-md-1">
            <button class="btn btn-sm" style="background-color: #019943" onclick="bukaModal()"><i style="color:white" class="icon-plus"></i></button>
        </div>
    </div>
</center>
<div class="row">
    <div class="col-md-12">
        <div class="widget">
            <div class="widget-header">
                <i class="icon-bar-chart"></i>
                <h3>Data Polres</h3>
            </div>
            <div class="widget-content">
            <div style="display:none" id="error" class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
            <div style="display:none" id="success" class="alert alert-success">
                <?php echo e(session('pesan')); ?>

            </div>
            <div class="widget-content">
                <table id="table" class="table table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Polres</th>
                            <th>Alamat</th>
                            <th style="text-align: center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no + 1); ?></td>
                            <td><?php echo e($row->cabang_nama); ?></td>
                            <td><?php echo $row->cabang_alamat; ?></td>
                            <td style="text-align: center">
                                <a onclick="edit('<?php echo e($row->cabang_id); ?>','<?php echo e($row->cabang_nama); ?>','<?php echo e($row->cabang_alamat); ?>')" class="icon-edit"></a>
                                <a href="<?php echo e(route('polres-delete', encrypt($row->cabang_id))); ?>" class="icon-trash"></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<br><br><br><br><br><br><br><br><br><br><br><br>


<!-- modal -->
<div class="modal" id="formModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">Add Polres</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="<?php echo e(route('polres-save')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
            <div class="modal-body">
                    <div class="col-md-12">
                        <label><b>Nama</b></label>
                        <input type="hidden" name="cabang_id" id="cabang_id">
                        <input type="hidden" name="cabang_kode" id="cabang_kode" value="1">
                        <input type="text" name="cabang_nama" id="cabang_nama" class="form-control">
                    </div>
                    <div class="col-md-12">
                        <label><b>Alamat</b></label>
                        <textarea name="cabang_alamat" id="cabang_alamat" cols="30" rows="3" class="form-control"></textarea>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-sm" style="background-color: #019943">Save</button>
                <button type="reset" class="btn btn-sm btn-secondary">Reset</button>
            </div>
        </form>
        </div>
    </div>
</div>

<?php if(session('validasi')): ?>
	<script>
		$('#error').show();
		setInterval(function(){ $('#error').hide(); }, 5000);
	</script>
<?php endif; ?>
<?php if(session('pesan')): ?>
	<script>
		$('#success').show();
		setInterval(function(){ $('#success').hide(); }, 5000);
	</script>
<?php endif; ?>


<script>
    function bukaModal(){
        $('#formModal').modal('show');
    }
    function edit(id, nama, alamat){
        $('#cabang_id').val(id);
        $('#cabang_nama').val(nama);
        $('#cabang_alamat').val(alamat);
        $('#formModal').modal('show');
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\kaltim\resources\views/backend/polres/polres.blade.php ENDPATH**/ ?>