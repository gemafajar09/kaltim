<div class="col-md-4">
    <div id="calendar"></div>
</div><?php /**PATH E:\laravel\kaltim\resources\views/backend/template/component/calender.blade.php ENDPATH**/ ?>