<table class="table table-striped">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Biro</th>
            <th>SURAT KETERANGAN PSIKOLOGI SIM A</th>
            <th>SURAT KETERANGAN PSIKOLOGI SIM C</th>
            <th>SURAT KETERANGAN PSIKOLOGI SIM A DAN C</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $isi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i+1); ?></td>
            <td><?php echo e($a->cabang_nama); ?></td>
            <td><?php echo e($a->sim_a_baru); ?></td>
            <td><?php echo e($a->sim_c_baru); ?></td>
            <td><?php echo e($a->sim_ac_baru); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<table class="table table-striped">
    <thead>
        <tr>
            <th>No</th>
            <th>SIMLINK 1</th>
            <th>SIMLINK 2</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $isi_simlink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i+1); ?></td>
            <td><?php echo e($a->simlink1); ?></td>
            <td><?php echo e($a->simlink2); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\laravel\kaltim\resources\views/backend/report/polresdetail.blade.php ENDPATH**/ ?>