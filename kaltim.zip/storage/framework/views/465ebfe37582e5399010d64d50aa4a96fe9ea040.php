<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($no + 1); ?></td>
    <td><?php echo e($row->tanggal); ?></td>
    <td><?php echo e($row->cabang_nama); ?></td>
    <td><?php echo e($row->sim_a); ?></td>
    <td><?php echo e($row->sim_c); ?></td>
    <td><?php echo e($row->sim_ac); ?></td>
    <!-- <td style="text-align: center">        
        <a href="<?php echo e(route('data-biro-delete', encrypt($row->id_detail))); ?>" class="icon-trash"></a>
    </td> -->
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\laravel\kaltim\resources\views/backend/report/report_biro_tabel.blade.php ENDPATH**/ ?>