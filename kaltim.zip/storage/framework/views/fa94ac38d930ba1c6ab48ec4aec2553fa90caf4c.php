<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="utf-8">
    <title>Login </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
	<link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(asset('/css/bootstrap-responsive.min.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(asset('/css/font-awesome.css')); ?>" rel="stylesheet">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">    
	<link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('/css/pages/signin.css')); ?>" rel="stylesheet" type="text/css">

</head>
<style>
	body {
	background-image: url("<?php echo e(asset('/img/backkaltim1.jpg')); ?>");
	/* background-repeat: repeat-y; */
	}
</style>

<body>
	
	<script src="<?php echo e(asset('/js/jquery-1.7.2.min.js')); ?>"></script>
	<script src="<?php echo e(asset('/js/bootstrap.js')); ?>"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	<script src="<?php echo e(asset('/js/signin.js')); ?>"></script>

	
	<center>
		<img src="<?php echo e(asset('/img/Lambang_Polda_Kaltim.png')); ?>" style="width:10%; padding-top:50px" alt="">
	</center>
	<div class="account-container">
		<div class="content clearfix">
			<form action="<?php echo e(route('data-user-login')); ?>" method="post">
				<?php echo csrf_field(); ?>
				<h1>Form Login</h1>		
				<div class="login-fields">
					<p>Please provide your details</p>
					<div class="field">
						<label for="username">Username</label>
						<input type="text" id="username" name="username" value="" placeholder="Username" class="login username-field" />
					</div> 
					<div class="field">
						<label for="password">Password:</label>
						<input type="password" id="password" name="password" value="" placeholder="Password" class="login password-field"/>
					</div>
				</div> 
				<div class="login-actions">
					<span class="login-checkbox">
						<input id="Field" name="Field" type="checkbox" class="field login-checkbox" value="First Choice" tabindex="4"/>
						<label class="choice" for="Field">Keep me signed in</label>
					</span>
					<button type="submit" class="button btn btn-success btn-large">Sign In</button>
				</div> 
			</form>
		</div>
	</div>

	
	<?php if(session('error')): ?>
		<script>
			toastr.error('<?php echo e(session('error')); ?>')
		</script>
	<?php endif; ?>
	<?php if(session('pesan')): ?>
		<script>
			toastr.info('<?php echo e(session('pesan')); ?>')
		</script>
	<?php endif; ?>
</body>

</html>
<?php /**PATH E:\laravel\kaltim\resources\views/backend/auth/login.blade.php ENDPATH**/ ?>