<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($no + 1); ?></td>
    <td><?php echo e($row->data_biro_tgl); ?></td>
    <td><?php echo e($row->cabang_nama); ?></td>
    <td><?php echo e($row->data_biro_sim_a_baru); ?></td>
    <td><?php echo e($row->data_biro_sim_c_baru); ?></td>
    <td><?php echo e($row->data_biro_sim_ac_baru); ?></td>
    <td><?php echo e($row->data_biro_sim_a_perpanjang); ?></td>
    <td><?php echo e($row->data_biro_sim_c_perpanjang); ?></td>
    <td><?php echo e($row->data_biro_sim_ac_perpanjang); ?></td>
    <td style="text-align: center">
        <a onclick="edit('<?php echo e($row->data_biro_id); ?>',
        '<?php echo e($row->cabang_nama); ?>',
        '<?php echo e($row->biro_id); ?>',
        '<?php echo e($row->data_biro_tgl); ?>',
        '<?php echo e($row->data_biro_sim_a_baru); ?>',
        '<?php echo e($row->data_biro_sim_c_baru); ?>',
        '<?php echo e($row->data_biro_sim_ac_baru); ?>',
        '<?php echo e($row->data_biro_sim_a_perpanjang); ?>',
        '<?php echo e($row->data_biro_sim_c_perpanjang); ?>',
        '<?php echo e($row->data_biro_sim_ac_perpanjang); ?>')" class="icon-edit"></a>
        
        <a href="<?php echo e(route('data-biro-delete', encrypt($row->data_biro_id))); ?>" class="icon-trash"></a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\laravel\kaltim\resources\views/backend/report/birotable.blade.php ENDPATH**/ ?>