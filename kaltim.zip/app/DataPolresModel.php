<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataPolresModel extends Model
{
    //
}
