<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataPolresModel extends Model
{
    protected $table = 'tb_data_polres';
}
