<style>
    .footer {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
    }
</style>
<div class="footer">
    <div class="footer-inner">
        <div class="container">
            <div class="row">
                <div class="span12"> &copy; 2021 <a href="#">Mediatama Web</a>. </div>
            </div>
        </div>
    </div>
</div>